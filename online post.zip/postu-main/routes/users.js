const express = require('express');
const { all, get } = require('../database/db');

const router = express.Router();

router.get('/:id', async (req, res) => {
    try {
        const user = await get(
            'SELECT id, username, email, created_at FROM users WHERE id = ?',
            [req.params.id]
        );

        if (!user) {
            return res.status(404).json({ error: 'Пользователь не найден' });
        }

        res.json({ user });
    } catch (error) {
        console.error('Ошибка получения пользователя:', error);
        res.status(500).json({ error: 'Ошибка сервера при получении пользователя' });
    }
});

router.get('/:id/posts', async (req, res) => {
    try {
        const posts = await all(`
            SELECT 
                p.id,
                p.title,
                p.content,
                p.created_at,
                p.updated_at,
                u.id as user_id,
                u.username
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE p.user_id = ?
            ORDER BY p.created_at DESC
        `, [req.params.id]);

        for (let post of posts) {
            const files = await all(
                'SELECT id, file_path, file_type, file_name, file_size FROM post_files WHERE post_id = ?',
                [post.id]
            );
            post.files = files;
        }

        res.json({ posts });
    } catch (error) {
        console.error('Ошибка получения постов пользователя:', error);
        res.status(500).json({ error: 'Ошибка сервера при получении постов пользователя' });
    }
});

module.exports = router;
