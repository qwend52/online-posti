const express = require('express');
const { all, get, run } = require('../database/db');
const authMiddleware = require('../middleware/auth');
const upload = require('../middleware/upload');

const router = express.Router();

router.get('/', async (req, res) => {
    try {
        const posts = await all(`
            SELECT 
                p.id,
                p.title,
                p.content,
                p.created_at,
                p.updated_at,
                u.id as user_id,
                u.username
            FROM posts p
            JOIN users u ON p.user_id = u.id
            ORDER BY p.created_at DESC
        `);

        for (let post of posts) {
            const files = await all(
                'SELECT id, file_path, file_type, file_name, file_size FROM post_files WHERE post_id = ?',
                [post.id]
            );
            post.files = files;
        }

        res.json({ posts });
    } catch (error) {
        console.error('Ошибка получения постов:', error);
        res.status(500).json({ error: 'Ошибка сервера при получении постов' });
    }
});

router.get('/:id', async (req, res) => {
    try {
        const post = await get(`
            SELECT 
                p.id,
                p.title,
                p.content,
                p.created_at,
                p.updated_at,
                u.id as user_id,
                u.username
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE p.id = ?
        `, [req.params.id]);

        if (!post) {
            return res.status(404).json({ error: 'Пост не найден' });
        }

        const files = await all(
            'SELECT id, file_path, file_type, file_name, file_size FROM post_files WHERE post_id = ?',
            [post.id]
        );
        post.files = files;

        res.json({ post });
    } catch (error) {
        console.error('Ошибка получения поста:', error);
        res.status(500).json({ error: 'Ошибка сервера при получении поста' });
    }
});

router.post('/', authMiddleware, upload.array('files', 10), async (req, res) => {
    try {
        const { title, content } = req.body;
        const userId = req.user.id;

        if (!title || !content) {
            return res.status(400).json({ error: 'Заголовок и содержание обязательны' });
        }

        const result = await run(
            'INSERT INTO posts (user_id, title, content) VALUES (?, ?, ?)',
            [userId, title, content]
        );

        const postId = result.id;

        if (req.files && req.files.length > 0) {
            for (const file of req.files) {
                await run(
                    'INSERT INTO post_files (post_id, file_path, file_type, file_name, file_size) VALUES (?, ?, ?, ?, ?)',
                    [postId, file.path, file.mimetype, file.originalname, file.size]
                );
            }
        }

        const post = await get(`
            SELECT 
                p.id,
                p.title,
                p.content,
                p.created_at,
                p.updated_at,
                u.id as user_id,
                u.username
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE p.id = ?
        `, [postId]);

        const files = await all(
            'SELECT id, file_path, file_type, file_name, file_size FROM post_files WHERE post_id = ?',
            [postId]
        );
        post.files = files;

        res.status(201).json({
            message: 'Пост успешно создан',
            post
        });
    } catch (error) {
        console.error('Ошибка создания поста:', error);
        res.status(500).json({ error: 'Ошибка сервера при создании поста' });
    }
});

router.put('/:id', authMiddleware, async (req, res) => {
    try {
        const { title, content } = req.body;
        const postId = req.params.id;
        const userId = req.user.id;

        const post = await get('SELECT user_id FROM posts WHERE id = ?', [postId]);

        if (!post) {
            return res.status(404).json({ error: 'Пост не найден' });
        }

        if (post.user_id !== userId) {
            return res.status(403).json({ error: 'Нет прав на редактирование этого поста' });
        }

        await run(
            'UPDATE posts SET title = ?, content = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
            [title, content, postId]
        );

        const updatedPost = await get(`
            SELECT 
                p.id,
                p.title,
                p.content,
                p.created_at,
                p.updated_at,
                u.id as user_id,
                u.username
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE p.id = ?
        `, [postId]);

        const files = await all(
            'SELECT id, file_path, file_type, file_name, file_size FROM post_files WHERE post_id = ?',
            [postId]
        );
        updatedPost.files = files;

        res.json({
            message: 'Пост успешно обновлён',
            post: updatedPost
        });
    } catch (error) {
        console.error('Ошибка обновления поста:', error);
        res.status(500).json({ error: 'Ошибка сервера при обновлении поста' });
    }
});

router.delete('/:id', authMiddleware, async (req, res) => {
    try {
        const postId = req.params.id;
        const userId = req.user.id;

        const post = await get('SELECT user_id FROM posts WHERE id = ?', [postId]);

        if (!post) {
            return res.status(404).json({ error: 'Пост не найден' });
        }

        if (post.user_id !== userId) {
            return res.status(403).json({ error: 'Нет прав на удаление этого поста' });
        }

        await run('DELETE FROM posts WHERE id = ?', [postId]);

        res.json({ message: 'Пост успешно удалён' });
    } catch (error) {
        console.error('Ошибка удаления поста:', error);
        res.status(500).json({ error: 'Ошибка сервера при удалении поста' });
    }
});

module.exports = router;
