require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const { initDatabase } = require('./database/db');


const authRoutes = require('./routes/auth');
const postsRoutes = require('./routes/posts');
const usersRoutes = require('./routes/users');

const app = express();
const PORT = process.env.PORT || 3000;


app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));


app.use('/uploads', express.static(path.join(__dirname, 'uploads')));


app.use('/api/auth', authRoutes);
app.use('/api/posts', postsRoutes);
app.use('/api/users', usersRoutes);


app.get('/', (req, res) => {
    res.json({
        message: 'API платформы онлайн постинга',
        version: '1.0.0',
        endpoints: {
            auth: {
                register: 'POST /api/auth/register',
                login: 'POST /api/auth/login'
            },
            posts: {
                getAll: 'GET /api/posts',
                getOne: 'GET /api/posts/:id',
                create: 'POST /api/posts (требуется авторизация)',
                update: 'PUT /api/posts/:id (требуется авторизация)',
                delete: 'DELETE /api/posts/:id (требуется авторизация)'
            },
            users: {
                getProfile: 'GET /api/users/:id',
                getUserPosts: 'GET /api/users/:id/posts'
            }
        }
    });
});


app.use((req, res) => {
    res.status(404).json({ error: 'Маршрут не найден' });
});


app.use((err, req, res, next) => {
    console.error('Ошибка сервера:', err);

    if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(413).json({ error: 'Файл слишком большой. Максимальный размер: 10MB' });
    }

    res.status(500).json({ error: 'Внутренняя ошибка сервера' });
});


initDatabase();

app.listen(PORT, () => {
    console.log(`Сервер запущен на порту ${PORT}`);
    console.log(`API доступен по адресу: http://localhost:${PORT}`);
});
