const jwt = require('jsonwebtoken');

const authMiddleware = (req, res, next) => {
    try {

        const authHeader = req.headers.authorization;

        if (!authHeader) {
            return res.status(401).json({ error: 'Токен не предоставлен' });
        }


        const token = authHeader.split(' ')[1];

        if (!token) {
            return res.status(401).json({ error: 'Неверный формат токена' });
        }


        const decoded = jwt.verify(token, process.env.JWT_SECRET);


        req.user = {
            id: decoded.userId,
            username: decoded.username
        };

        next();
    } catch (error) {
        if (error.name === 'JsonWebTokenError') {
            return res.status(401).json({ error: 'Недействительный токен' });
        }
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({ error: 'Токен истёк' });
        }
        return res.status(500).json({ error: 'Ошибка авторизации' });
    }
};

module.exports = authMiddleware;
